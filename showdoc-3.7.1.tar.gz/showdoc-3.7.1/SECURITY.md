# Security Policy

## Supported Versions


The latest version of the security report is currently accepted.

Before reporting, you can test the latest release or the latest master branch code of the project


## Reporting a Vulnerability

Please contact email xing7th#gmail.com (change # into @)   report the vulnerability. We will reply to you by email


# 安全策略

## 支持的版本

目前接受最新版本的安全报告。

在报告之前，你可以测试项目的最新发行版本或最新master分支代码

## 报告漏洞

请联系电子邮件xing7th#gmail.com（将#更改为@）报告该漏洞。我们将通过电子邮件回复你
