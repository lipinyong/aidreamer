<?php

namespace Api\Model;

use Think\Model;

class RunapiDbConfigModel extends Model
{
    /**
     * 数据表名
     *
     * @var string
     */
    protected $tableName = 'runapi_db_config';
}

