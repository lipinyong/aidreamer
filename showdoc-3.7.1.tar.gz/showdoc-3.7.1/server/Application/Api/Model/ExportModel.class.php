<?php

namespace Api\Model;

use Api\Model\BaseModel;

/**
 * 
 * @author star7th      
 */
class ExportModel
{

    protected $autoCheckFields = false;  //一定要关闭字段缓存，不然会报找不到表的错误


}
